<?php   
    $server="localhost"; 
    $user="root"; 
    $pass=""; 
    $db="shoppingcarttrial"; 
       
    $mysqli = mysqli_connect($server, $user, $pass, $db);
 
    if($mysqli->connect_error) {
        die("Sorry, can't connect to the mysql.");
    }
?>